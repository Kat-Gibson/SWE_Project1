namespace CalculatorUnitTests;

public class TestCalculator
{
    [Test]
    public void Test1()
    {
        Assert.Pass();
    }
}