﻿namespace Calculator;

public class CalculatorEngine
{
    public static double CalculateWebInputs(int inputA, int inputB)
    {
        return 5.0;
    }
}